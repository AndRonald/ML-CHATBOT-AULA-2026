# ==============================================================================
# BLOCO 1 — GERADOR DE DATASET SINTÉTICO
# Projeto : Sistema de Predição de Risco Clínico
# Arquivo : 1_gerador_dataset.py
# Descrição: Gera 2 000 registros de pacientes fictícios com variáveis
#            biomédicas e classifica cada um em três níveis de risco clínico.
# Saída   : pacientes.csv
# Libs    : pandas, numpy
# ==============================================================================

import numpy as np
import pandas as pd

# ------------------------------------------------------------------------------
# CONFIGURAÇÃO GLOBAL
# Fixar a semente garante que o dataset seja idêntico a cada execução —
# fundamental para reprodutibilidade em experimentos acadêmicos.
# ------------------------------------------------------------------------------
np.random.seed(42)

N = 2000  # Total de registros a gerar

# ==============================================================================
# SEÇÃO 1 — NOMES FICTÍCIOS
# Lista de primeiros nomes comuns no Brasil, sem sobrenome.
# np.random.choice sorteia N nomes com reposição (replace=True).
# ==============================================================================

nomes_masculinos = [
    "Lucas", "Pedro", "Carlos", "André", "Bruno", "Rafael", "Diego",
    "Felipe", "Marcos", "João", "Thiago", "Gustavo", "Eduardo", "Rodrigo",
    "Fernando", "Alexandre", "Vinícius", "Mateus", "Henrique", "Leandro",
    "Ricardo", "Fabio", "Sergio", "Renato", "Daniel", "Marcelo", "Alan"
]

nomes_femininos = [
    "Ana", "Maria", "Julia", "Fernanda", "Camila", "Beatriz", "Larissa",
    "Letícia", "Amanda", "Gabriela", "Isabela", "Mariana", "Renata",
    "Patrícia", "Luciana", "Vanessa", "Sandra", "Cristina", "Adriana",
    "Tatiane", "Carla", "Priscila", "Simone", "Elaine", "Mônica", "Claudia"
]

todos_os_nomes = nomes_masculinos + nomes_femininos
nomes = np.random.choice(todos_os_nomes, size=N, replace=True)

# ==============================================================================
# SEÇÃO 2 — VARIÁVEIS BIOMÉDICAS
# Cada variável é gerada com distribuição normal (loc=média, scale=desvio padrão)
# e depois limitada (np.clip) a uma faixa biologicamente plausível.
# Referências clínicas usadas nas faixas:
#   Glicose      → OMS / ADA (American Diabetes Association)
#   Pressão      → JNC 8 / ESH 2023
#   IMC          → OMS
#   Colesterol   → NCEP ATP III
# ==============================================================================

# IDADE — população adulta geral (18-99 anos)
# Média 50, desvio 18: distribui razoavelmente entre jovens e idosos
idade = np.random.normal(loc=50, scale=18, size=N)
idade = np.clip(idade, 18, 99).astype(int)

# GLICOSE em jejum (mg/dL)
# Normal: 70–99 | Pré-diabetes: 100–125 | Diabetes: ≥ 126
glicose = np.random.normal(loc=110, scale=30, size=N)
glicose = np.clip(glicose, 60, 300).round(1)

# PRESSÃO ARTERIAL SISTÓLICA (mmHg)
# Normal: < 120 | Elevada: 120–129 | Hipertensão estágio 1: 130–139 | estágio 2: ≥ 140
pressao = np.random.normal(loc=125, scale=20, size=N)
pressao = np.clip(pressao, 70, 200).round(1)

# IMC — Índice de Massa Corporal (kg/m²)
# Abaixo do peso: < 18.5 | Normal: 18.5–24.9 | Sobrepeso: 25–29.9 | Obeso: ≥ 30
imc = np.random.normal(loc=27, scale=6, size=N)
imc = np.clip(imc, 14, 50).round(1)

# COLESTEROL TOTAL (mg/dL)
# Desejável: < 200 | Limítrofe: 200–239 | Alto: ≥ 240
colesterol = np.random.normal(loc=210, scale=45, size=N)
colesterol = np.clip(colesterol, 100, 400).round(1)

# ==============================================================================
# SEÇÃO 3 — REGRA DE RISCO CLÍNICO (variável alvo)
#
# Cada critério clínico acrescenta pontos ao "score de risco" do paciente.
# A lógica reflete guidelines reais (limites de alerta clínico):
#
#   score 0–2 → classe 0 (baixo risco)
#   score 3–5 → classe 1 (risco médio)
#   score ≥ 6 → classe 2 (risco alto)
#
# Um pequeno ruído aleatório (0 ou 1) simula fatores não mensurados
# (histórico familiar, tabagismo, sedentarismo, etc.).
# ==============================================================================

score = np.zeros(N)

# Glicose: pré-diabetes (+1), diabetes confirmada (+1 adicional)
score += (glicose >= 100).astype(int)
score += (glicose >= 126).astype(int)

# Pressão arterial: hipertensão (+1), hipertensão severa (+1 adicional)
score += (pressao >= 130).astype(int)
score += (pressao >= 160).astype(int)

# IMC: sobrepeso (+1), obesidade (+1 adicional)
score += (imc >= 25).astype(int)
score += (imc >= 30).astype(int)

# Colesterol: limítrofe (+1), alto (+1 adicional)
score += (colesterol >= 200).astype(int)
score += (colesterol >= 240).astype(int)

# Idade: risco cardiovascular aumenta com a idade
score += (idade >= 50).astype(int)
score += (idade >= 65).astype(int)

# Ruído clínico: fatores não mensurados (0 ou 1 ponto aleatório)
score += np.random.randint(0, 2, size=N)

# Converte score em classe de risco
risco = np.where(score <= 2, 0,
        np.where(score <= 5, 1, 2))

# ==============================================================================
# SEÇÃO 4 — MONTAGEM DO DATAFRAME E EXPORTAÇÃO
# ==============================================================================

df = pd.DataFrame({
    "nome":       nomes,
    "idade":      idade,
    "glicose":    glicose,
    "pressao":    pressao,
    "imc":        imc,
    "colesterol": colesterol,
    "risco":      risco
})

# Salva como CSV
# index=False     → não inclui a coluna de índice automático do Pandas
# encoding utf-8-sig → compatível com Microsoft Excel (trata acentos)
caminho = "pacientes.csv"
df.to_csv(caminho, index=False, encoding="utf-8-sig")

# ==============================================================================
# SEÇÃO 5 — RELATÓRIO DE SAÍDA NO TERMINAL
# ==============================================================================

labels = {0: "Baixo risco", 1: "Risco médio", 2: "Risco alto"}

print("=" * 60)
print("  DATASET GERADO COM SUCESSO")
print("=" * 60)
print(f"  Arquivo : {caminho}")
print(f"  Registros: {len(df):,}")
print()
print("  Distribuição da variável alvo (risco):")
for cls, qtd in df["risco"].value_counts().sort_index().items():
    pct = qtd / N * 100
    print(f"    Classe {cls} — {labels[cls]:<15}: {qtd:>5} pacientes  ({pct:.1f}%)")
print()
print("  Estatísticas descritivas das features:")
print(df[["idade","glicose","pressao","imc","colesterol"]].describe().round(2).to_string())
print()
print("  Primeiros 5 registros:")
print(df.head().to_string(index=False))
print("=" * 60)
