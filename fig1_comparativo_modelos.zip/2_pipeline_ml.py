# ==============================================================================
# BLOCO 2 — PIPELINE COMPLETO DE MACHINE LEARNING
# Projeto : Sistema de Predição de Risco Clínico
# Arquivo : 2_pipeline_ml.py
# Descrição: Lê pacientes.csv, treina três classificadores, avalia e compara
#            com métricas completas, gera visualizações e prediz um novo caso.
# Libs    : pandas, numpy, scikit-learn, matplotlib
#
# EXECUTE ESTE ARQUIVO APÓS: 1_gerador_dataset.py
# ==============================================================================

# ── Bibliotecas padrão ────────────────────────────────────────────────────────
import warnings
warnings.filterwarnings("ignore")   # Remove avisos de convergência em aula

import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
import matplotlib.gridspec as gridspec

# ── scikit-learn: pré-processamento ──────────────────────────────────────────
from sklearn.preprocessing import StandardScaler, label_binarize
from sklearn.model_selection import train_test_split, cross_val_score, StratifiedKFold

# ── scikit-learn: modelos ─────────────────────────────────────────────────────
from sklearn.linear_model import LogisticRegression
from sklearn.ensemble import RandomForestClassifier
from sklearn.neighbors import KNeighborsClassifier

# ── scikit-learn: métricas ────────────────────────────────────────────────────
from sklearn.metrics import (
    accuracy_score, precision_score, recall_score, f1_score,
    confusion_matrix, ConfusionMatrixDisplay,
    roc_curve, auc
)

# ==============================================================================
# ETAPA 1 — LEITURA E INSPEÇÃO DO DATASET
# ==============================================================================
print("\n" + "=" * 65)
print("  ETAPA 1 — CARREGAMENTO DO DATASET")
print("=" * 65)

df = pd.read_csv("pacientes.csv")

print(f"  Shape        : {df.shape[0]:,} linhas × {df.shape[1]} colunas")
print(f"  Colunas      : {list(df.columns)}")
print()

# Verificação de valores nulos — etapa obrigatória em qualquer pipeline real
nulos = df.isnull().sum()
if nulos.sum() == 0:
    print("  ✓ Nenhum valor nulo encontrado.")
else:
    print(f"  ⚠ Valores nulos encontrados:\n{nulos[nulos > 0]}")
print()

print("  Amostra (5 registros):")
print(df.head().to_string(index=False))
print()

# ==============================================================================
# ETAPA 2 — SEPARAÇÃO DE FEATURES (X) E TARGET (y)
#
# A coluna 'nome' é apenas identificadora — não possui poder preditivo.
# A coluna 'risco' é o que queremos prever.
# As 5 colunas restantes formam a matriz de features X.
# ==============================================================================
print("=" * 65)
print("  ETAPA 2 — SEPARAÇÃO DE FEATURES E TARGET")
print("=" * 65)

FEATURES = ["idade", "glicose", "pressao", "imc", "colesterol"]

X = df[FEATURES]   # Matriz de entrada  — shape (2000, 5)
y = df["risco"]    # Vetor alvo         — valores: 0, 1, 2

print(f"  Features (X): {FEATURES}")
print(f"  Target   (y): 'risco'  — classes {sorted(y.unique())}")
print(f"  Shape X: {X.shape}   |   Shape y: {y.shape}")
print()
print("  Distribuição das classes:")
for cls, cnt in y.value_counts().sort_index().items():
    rotulo = {0: "Baixo", 1: "Médio", 2: "Alto"}[cls]
    print(f"    Classe {cls} ({rotulo}): {cnt:>5} amostras  ({cnt/len(y)*100:.1f}%)")
print()

# ==============================================================================
# ETAPA 3 — DIVISÃO TREINO / TESTE  (80 % / 20 %)
#
# test_size=0.2  → 400 amostras para teste, 1600 para treino
# stratify=y     → mantém a proporção de classes nos dois conjuntos
# random_state   → resultado reprodutível a cada execução
# ==============================================================================
print("=" * 65)
print("  ETAPA 3 — DIVISÃO TREINO / TESTE  (80% / 20%)")
print("=" * 65)

X_train, X_test, y_train, y_test = train_test_split(
    X, y, test_size=0.2, stratify=y, random_state=42
)

print(f"  Treino : {X_train.shape[0]:>5} amostras")
print(f"  Teste  : {X_test.shape[0]:>5} amostras")
print()

# ==============================================================================
# ETAPA 4 — NORMALIZAÇÃO COM STANDARDSCALER
#
# StandardScaler transforma cada feature para média ≈ 0 e desvio padrão ≈ 1.
#
# REGRA FUNDAMENTAL:
#   → fit_transform() SOMENTE no treino (aprende média e desvio do treino)
#   → transform()     no teste (aplica os valores aprendidos no treino)
#
# Por que isso importa?
#   Se fizermos fit no conjunto de teste, estaríamos "vazando" informação
#   do futuro para o modelo — isso invalida a avaliação (data leakage).
# ==============================================================================
print("=" * 65)
print("  ETAPA 4 — NORMALIZAÇÃO COM STANDARDSCALER")
print("=" * 65)

scaler = StandardScaler()

X_train_sc = scaler.fit_transform(X_train)   # aprende + transforma
X_test_sc  = scaler.transform(X_test)        # só transforma

print("  Verificação pós-normalização (treino) — esperado: média ≈ 0, std ≈ 1")
print(f"  {'Feature':<12} {'Média':>10} {'Desvio':>10}")
print("  " + "-" * 36)
for feat, med, std in zip(FEATURES,
                          X_train_sc.mean(axis=0),
                          X_train_sc.std(axis=0)):
    print(f"  {feat:<12} {med:>10.4f} {std:>10.4f}")
print()

# ==============================================================================
# ETAPA 5 — DEFINIÇÃO DOS MODELOS
#
# Três algoritmos de classificação com propósitos distintos:
#
# 1. Regressão Logística
#    Modelo linear, interpretável, boa linha de base (baseline).
#    Usa Softmax para multiclasse (multi_class='auto').
#
# 2. Random Forest
#    Ensemble de árvores de decisão. Robusto, não-linear.
#    n_estimators=100: 100 árvores votam na predição final.
#
# 3. KNN (K-Nearest Neighbors)
#    Algoritmo baseado em distância. Sem fase de "treinamento" explícita.
#    k=7: considera os 7 vizinhos mais próximos para votar na classe.
# ==============================================================================
print("=" * 65)
print("  ETAPA 5 — CONFIGURAÇÃO DOS MODELOS")
print("=" * 65)

modelos = {
    "Regressão Logística": LogisticRegression(
        max_iter=1000,        # garante convergência
        solver="lbfgs",       # solver robusto para multiclasse
        random_state=42
    ),
    "Random Forest": RandomForestClassifier(
        n_estimators=100,     # 100 árvores no ensemble
        max_depth=10,         # limita profundidade — evita overfitting
        random_state=42
    ),
    "KNN": KNeighborsClassifier(
        n_neighbors=7,        # 7 vizinhos — número ímpar evita empate
        metric="euclidean"    # distância euclidiana (adequada para dados normalizados)
    )
}

for nome, modelo in modelos.items():
    print(f"  ✓ {nome:<25} → {type(modelo).__name__}")
print()

# ==============================================================================
# ETAPA 6 — TREINAMENTO, AVALIAÇÃO E VALIDAÇÃO CRUZADA
#
# Para cada modelo:
#   a) Treina com X_train_sc
#   b) Prediz em X_test_sc
#   c) Calcula 4 métricas (accuracy, precision, recall, F1)
#   d) Realiza validação cruzada k=5 (StratifiedKFold)
#
# Métricas com average="macro":
#   Calcula a métrica por classe e tira a média simples.
#   Trata todas as classes com o mesmo peso (independente do tamanho).
#
# Validação cruzada k=5:
#   Divide o treino em 5 partes; usa 4 para treinar e 1 para validar,
#   rotacionando até todas as partes terem sido o conjunto de validação.
#   Retorna 5 scores de acurácia — a média indica a capacidade de generalização.
# ==============================================================================
print("=" * 65)
print("  ETAPA 6 — TREINAMENTO E AVALIAÇÃO")
print("=" * 65)

kfold = StratifiedKFold(n_splits=5, shuffle=True, random_state=42)

resultados = {}   # armazena métricas e objetos para uso posterior

for nome_m, modelo in modelos.items():
    print(f"\n  ── {nome_m} ──────────────────────────────────")

    # ---- TREINO ----
    modelo.fit(X_train_sc, y_train)

    # ---- PREDIÇÃO ----
    y_pred = modelo.predict(X_test_sc)

    # ---- MÉTRICAS ----
    acc  = accuracy_score(y_test, y_pred)
    prec = precision_score(y_test, y_pred, average="macro", zero_division=0)
    rec  = recall_score(y_test, y_pred, average="macro", zero_division=0)
    f1   = f1_score(y_test, y_pred, average="macro", zero_division=0)

    # ---- VALIDAÇÃO CRUZADA ----
    cv_sc = cross_val_score(modelo, X_train_sc, y_train,
                            cv=kfold, scoring="accuracy")
    cv_med = cv_sc.mean()
    cv_std = cv_sc.std()

    # Guarda tudo
    resultados[nome_m] = {
        "modelo":    modelo,
        "y_pred":    y_pred,
        "acuracia":  acc,
        "precision": prec,
        "recall":    rec,
        "f1":        f1,
        "cv_media":  cv_med,
        "cv_std":    cv_std,
        "cv_scores": cv_sc
    }

    print(f"    Acurácia  (teste) : {acc:.4f}  ({acc*100:.2f}%)")
    print(f"    Precision (macro) : {prec:.4f}")
    print(f"    Recall    (macro) : {rec:.4f}")
    print(f"    F1-Score  (macro) : {f1:.4f}")
    print(f"    CV Acurácia (k=5) : {cv_med:.4f} ± {cv_std:.4f}")
    print(f"    Scores por fold   : {[round(s, 4) for s in cv_sc]}")

print()

# ==============================================================================
# ETAPA 7 — COMPARAÇÃO E SELEÇÃO DO MELHOR MODELO
#
# Critério de seleção: maior F1-Score (macro)
# O F1-Score é preferido à acurácia quando há mais de uma classe, pois
# equilibra precision e recall e não é enganado por classes majoritárias.
# ==============================================================================
print("=" * 65)
print("  ETAPA 7 — COMPARAÇÃO DOS MODELOS")
print("=" * 65)

ranking = sorted(resultados.items(), key=lambda x: x[1]["f1"], reverse=True)

print(f"\n  {'Modelo':<25} {'Acurácia':>9} {'Precision':>10} {'Recall':>8}"
      f" {'F1':>8} {'CV ± std':>14}")
print("  " + "─" * 78)
for nome_m, res in ranking:
    print(f"  {nome_m:<25} {res['acuracia']:>9.4f} {res['precision']:>10.4f}"
          f" {res['recall']:>8.4f} {res['f1']:>8.4f}"
          f"  {res['cv_media']:.4f}±{res['cv_std']:.4f}")

melhor_nome = ranking[0][0]
melhor_res  = ranking[0][1]
melhor_mod  = melhor_res["modelo"]
melhor_pred = melhor_res["y_pred"]

print()
print(f"  ★  MELHOR MODELO : {melhor_nome}")
print(f"     F1-Score      : {melhor_res['f1']:.4f}")
print(f"     Acurácia      : {melhor_res['acuracia']:.4f}  ({melhor_res['acuracia']*100:.2f}%)")
print()

# ==============================================================================
# ETAPA 8 — VISUALIZAÇÕES
#
# Figura 1 — Gráfico comparativo de métricas (barras + linhas de fold)
# Figura 2 — Matriz de confusão do melhor modelo
# Figura 3 — Curva ROC (se o modelo suportar predict_proba)
# ==============================================================================
print("=" * 65)
print("  ETAPA 8 — GERANDO VISUALIZAÇÕES")
print("=" * 65)

# Paleta de cores para os três modelos
CORES      = ["#3A86FF", "#FF6B35", "#2EC4B6"]
CLASSES    = ["Baixo (0)", "Médio (1)", "Alto (2)"]
nomes_ord  = [n for n, _ in ranking]
x_pos      = np.arange(len(nomes_ord))
larg       = 0.22

# ──────────────────────────────────────────────────────────────────────────────
# FIGURA 1 — Comparativo de desempenho
# ──────────────────────────────────────────────────────────────────────────────
fig1, (ax1, ax2) = plt.subplots(1, 2, figsize=(14, 5))
fig1.suptitle("Comparativo de Desempenho dos Modelos",
              fontsize=14, fontweight="bold", y=1.01)

# Subplot A — barras por métrica
acur  = [resultados[n]["acuracia"]  for n in nomes_ord]
f1s   = [resultados[n]["f1"]        for n in nomes_ord]
cvs   = [resultados[n]["cv_media"]  for n in nomes_ord]
errs  = [resultados[n]["cv_std"]    for n in nomes_ord]

b1 = ax1.bar(x_pos - larg, acur, larg, label="Acurácia",  color=CORES[0])
b2 = ax1.bar(x_pos,         f1s, larg, label="F1-Score",  color=CORES[1])
b3 = ax1.bar(x_pos + larg,  cvs, larg, label="CV Média",  color=CORES[2],
             yerr=errs, capsize=5, error_kw={"elinewidth": 1.5})

ax1.set_title("Acurácia, F1-Score e Validação Cruzada", fontsize=11)
ax1.set_xticks(x_pos)
ax1.set_xticklabels(nomes_ord, rotation=10, ha="right")
ax1.set_ylim(0, 1.12)
ax1.set_ylabel("Score")
ax1.legend(fontsize=9)
ax1.grid(axis="y", alpha=0.3, linestyle="--")
ax1.spines[["top", "right"]].set_visible(False)

# Rótulos de valor sobre as barras
for bar_group in [b1, b2, b3]:
    for bar in bar_group:
        h = bar.get_height()
        ax1.text(bar.get_x() + bar.get_width() / 2, h + 0.012,
                 f"{h:.3f}", ha="center", va="bottom", fontsize=7.5)

# Subplot B — scores por fold (mostra estabilidade do modelo)
for i, (nome_m, res) in enumerate(ranking):
    ax2.plot(range(1, 6), res["cv_scores"],
             marker="o", label=nome_m, color=CORES[i],
             linewidth=2, markersize=6)

ax2.set_title("Variação de Acurácia por Fold (CV k=5)", fontsize=11)
ax2.set_xlabel("Fold")
ax2.set_ylabel("Acurácia")
ax2.set_xticks(range(1, 6))
ax2.set_ylim(0.5, 1.05)
ax2.legend(fontsize=9)
ax2.grid(alpha=0.3, linestyle="--")
ax2.spines[["top", "right"]].set_visible(False)

plt.tight_layout()
plt.savefig("fig1_comparativo_modelos.png", dpi=150, bbox_inches="tight")
plt.show()
print("  ✓ fig1_comparativo_modelos.png salva")

# ──────────────────────────────────────────────────────────────────────────────
# FIGURA 2 — Matriz de Confusão do melhor modelo
#
# Cada linha representa a classe REAL; cada coluna, a classe PREDITA.
# A diagonal principal indica acertos; fora da diagonal, erros.
# Quanto mais concentrada na diagonal, melhor o modelo.
# ──────────────────────────────────────────────────────────────────────────────
fig2, ax3 = plt.subplots(figsize=(6, 5))

cm   = confusion_matrix(y_test, melhor_pred)
disp = ConfusionMatrixDisplay(confusion_matrix=cm, display_labels=CLASSES)
disp.plot(ax=ax3, colorbar=True, cmap="Blues")

ax3.set_title(f"Matriz de Confusão — {melhor_nome}",
              fontsize=12, fontweight="bold")
ax3.set_xlabel("Classe Predita", fontsize=10)
ax3.set_ylabel("Classe Real",    fontsize=10)

plt.tight_layout()
plt.savefig("fig2_matriz_confusao.png", dpi=150, bbox_inches="tight")
plt.show()
print("  ✓ fig2_matriz_confusao.png salva")

# Interpretação textual da matriz
print()
print(f"  Leitura da matriz ({melhor_nome}):")
for i, cls in enumerate(CLASSES):
    acertos = cm[i, i]
    total   = cm[i, :].sum()
    print(f"    {cls:<12}: {acertos}/{total} acertos  ({acertos/total*100:.1f}%)")

# ──────────────────────────────────────────────────────────────────────────────
# FIGURA 3 — Curva ROC (One-vs-Rest para multiclasse)
#
# Para cada classe, calculamos:
#   FPR (False Positive Rate) no eixo X
#   TPR (True Positive Rate / Recall) no eixo Y
#
# AUC (Área Sob a Curva):
#   AUC = 1.0 → modelo perfeito
#   AUC = 0.5 → modelo aleatório (linha diagonal)
#   AUC > 0.9 → excelente separação entre classes
# ──────────────────────────────────────────────────────────────────────────────
if hasattr(melhor_mod, "predict_proba"):
    fig3, ax4 = plt.subplots(figsize=(7, 5))

    y_test_bin = label_binarize(y_test, classes=[0, 1, 2])
    y_prob     = melhor_mod.predict_proba(X_test_sc)
    labels_roc = ["Baixo risco", "Risco médio", "Risco alto"]

    for i in range(3):
        fpr, tpr, _ = roc_curve(y_test_bin[:, i], y_prob[:, i])
        roc_auc     = auc(fpr, tpr)
        ax4.plot(fpr, tpr, color=CORES[i], lw=2,
                 label=f"Classe {i} — {labels_roc[i]}  (AUC = {roc_auc:.3f})")

    # Linha de referência: modelo que chuta aleatoriamente
    ax4.plot([0, 1], [0, 1], "k--", lw=1, alpha=0.5,
             label="Aleatório  (AUC = 0.500)")

    ax4.set_xlabel("Taxa de Falsos Positivos (FPR)", fontsize=10)
    ax4.set_ylabel("Taxa de Verdadeiros Positivos (TPR)", fontsize=10)
    ax4.set_title(f"Curva ROC — {melhor_nome}", fontsize=12, fontweight="bold")
    ax4.legend(loc="lower right", fontsize=9)
    ax4.grid(alpha=0.3, linestyle="--")
    ax4.spines[["top", "right"]].set_visible(False)

    plt.tight_layout()
    plt.savefig("fig3_curva_roc.png", dpi=150, bbox_inches="tight")
    plt.show()
    print("  ✓ fig3_curva_roc.png salva")
else:
    print("  ℹ Curva ROC não disponível para este modelo (sem predict_proba).")

print()

# ==============================================================================
# ETAPA 9 — PREDIÇÃO PARA UM NOVO PACIENTE
#
# Simula um caso clínico real: dados chegam "crus", precisam ser
# normalizados com o MESMO scaler treinado, e então classificados.
#
# NUNCA instancie um novo StandardScaler aqui — use o objeto `scaler`
# que já aprendeu a média/desvio do treino.
# ==============================================================================
print("=" * 65)
print("  ETAPA 9 — PREDIÇÃO PARA NOVO PACIENTE")
print("=" * 65)

# Dados do paciente hipotético
novo = {
    "nome":       "Roberto",
    "idade":       58,
    "glicose":    142.0,    # Acima do limiar diabético (≥ 126)
    "pressao":    148.0,    # Hipertensão estágio 2
    "imc":         31.8,    # Obesidade grau I (≥ 30)
    "colesterol": 248.0     # Colesterol alto (≥ 240)
}

# Referências clínicas para exibição contextual
refs = {
    "idade":      "anos         (faixa: 18–99)",
    "glicose":    "mg/dL        (normal: 70–99)",
    "pressao":    "mmHg sist.   (normal: < 120)",
    "imc":        "kg/m²        (normal: 18.5–24.9)",
    "colesterol": "mg/dL        (desejável: < 200)"
}

print(f"\n  Paciente: {novo['nome']}")
print(f"\n  {'Variável':<13} {'Valor':>8}  Referência")
print("  " + "─" * 52)
for feat in FEATURES:
    print(f"  {feat:<13} {novo[feat]:>8.1f}  {refs[feat]}")

# Monta array 2D (1 × 5) — formato exigido pelo scikit-learn
novo_X     = np.array([[novo[f] for f in FEATURES]])

# Normaliza com o scaler já ajustado no treino
novo_X_sc  = scaler.transform(novo_X)

# Predição da classe
classe_pred = melhor_mod.predict(novo_X_sc)[0]

# Probabilidades por classe (se disponível)
if hasattr(melhor_mod, "predict_proba"):
    probs = melhor_mod.predict_proba(novo_X_sc)[0]
else:
    probs = None

# Mapeamento de resultado para linguagem humana
mapa = {
    0: ("BAIXO RISCO",  "✅",
        "Hábitos saudáveis. Check-up anual recomendado."),
    1: ("RISCO MÉDIO",  "⚠️ ",
        "Atenção. Consulta semestral e revisão de dieta e atividade física."),
    2: ("RISCO ALTO",   "🚨",
        "Encaminhamento médico imediato. Monitoramento contínuo necessário.")
}

nivel, icone, recomendacao = mapa[classe_pred]

# ── Exibição do resultado ──────────────────────────────────────────────────
print()
print("  ┌─────────────────────────────────────────────┐")
print(f"  │  {icone}  RESULTADO DA PREDIÇÃO CLÍNICA          │")
print("  ├─────────────────────────────────────────────┤")
print(f"  │  Paciente        : {novo['nome']:<26}│")
print(f"  │  Modelo utilizado: {melhor_nome:<26}│")
print(f"  │  Classe predita  : {classe_pred}  →  {nivel:<21}│")
print("  └─────────────────────────────────────────────┘")

if probs is not None:
    print()
    print("  Probabilidades por classe:")
    labels_prob = ["Baixo risco (0)", "Risco médio (1)", "Risco alto  (2)"]
    for lbl, p in zip(labels_prob, probs):
        barra = "█" * int(p * 30)
        print(f"    {lbl} : {p*100:5.1f}%  {barra}")

print()
print(f"  Recomendação: {recomendacao}")

# ==============================================================================
# ENCERRAMENTO
# ==============================================================================
print()
print("=" * 65)
print("  PIPELINE CONCLUÍDO COM SUCESSO")
print(f"  Arquivos gerados:")
print(f"    • fig1_comparativo_modelos.png")
print(f"    • fig2_matriz_confusao.png")
print(f"    • fig3_curva_roc.png         (se suportado)")
print("=" * 65)
